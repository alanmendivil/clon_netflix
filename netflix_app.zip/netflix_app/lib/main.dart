import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Netflix UI',
      theme: ThemeData(
        primarySwatch: Colors.red,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: _buildAppBar(),
      body: ListView(
        children: [
          _buildSection("Top 5 populares", _getTop5Popular()),
          _buildPopularSection("Las 10 series más populares"),
          _buildSection("Mi lista", _getMYlistaImagenes()),
          _buildSection("Telenovelas colombianas", _getColombia()),
        ],
      ),
    );
  }


  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.black87,
      title: Text("NETNET"),
      actions: [
        SizedBox(width: 20),
      ],
    );
  }


  Widget _buildPopularSection(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle(title),
          SizedBox(height: 10),
          Container(
            height: 200,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: _getPopularSeriesImagenes(),
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildSection(String title, List<String> images) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle(title),
          SizedBox(height: 10),
          Container(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: images.length,
              itemBuilder: (context, index) => _buildImageItem(images[index]),
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Text(
        title,
        style: TextStyle(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildImageItem(String imagePath) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8.0),
        child: Image.asset(
          imagePath,
          width: 150,
          fit: BoxFit.cover,
        ),
      ),
    );
  }


  List<String> _getTop5Popular() {
    return [
      'assets/images/elite.jpg',
      'assets/images/you.jpg',
      'assets/images/la-casa-de-papel.jpg',
      'assets/images/griselda.jpg',
      'assets/images/lucifer.jpg',
    ];
  }

  List<String> _getMYlistaImagenes() {
    return [
      'assets/images/rosario-tijeras.jpg',
      'assets/images/Ozark.webp',
      'assets/images/perfil.jpg',
    ];
  }

  List<Widget> _getPopularSeriesImagenes() {
    return [
      'assets/images/la-serpiente.jpg',
      'assets/images/pablo-escobar.jpg',
      'assets/images/el-cartel-de-los-sapos-el-origen.jpg',
      'assets/images/el-chapo.jpg',
      'assets/images/accidente.jpg',
      'assets/images/narcos.jpg',
      'assets/images/dhamer.jpg',
      'assets/images/resident.jpg',
      'assets/images/juanpis.jpg',
      'assets/images/falsa-identidad.jpg',
    ].map((imagePath) => _buildImageItem(imagePath)).toList();
  }

  List<String> _getColombia() {
    return [
      'assets/images/pasion-de-gavilanes.webp',
      'assets/images/ley-secreta.jpg',
      'assets/images/reina-del-flow.webp',
      'assets/images/sin-senos-no-hay-paraiso.jpg',
    ];
  }
}
